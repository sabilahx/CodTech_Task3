from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)
model = joblib.load("iris_model.pkl")  # Make sure this file exists

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None  # Default value

    if request.method == "POST":
        try:
            sepal_length = float(request.form["sepal_length"])
            sepal_width = float(request.form["sepal_width"])
            petal_length = float(request.form["petal_length"])
            petal_width = float(request.form["petal_width"])

            features = np.array([[sepal_length, sepal_width, petal_length, petal_width]])
            pred_class = model.predict(features)[0]
            class_names = ["setosa", "versicolor", "virginica"]
            prediction = class_names[pred_class]
        except Exception as e:
            prediction = f"Error: {e}"

    return render_template("index.html", prediction=prediction)

# ✅ This is needed to RUN the app
if __name__ == "__main__":
    app.run(debug=True)

